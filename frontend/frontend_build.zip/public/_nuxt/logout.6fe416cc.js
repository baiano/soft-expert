import{_ as e,c as o,o as c}from"./entry.b29b36ec.js";const t={};function n(r,a){return c(),o("div",null," Page: foo ")}const _=e(t,[["render",n]]);export{_ as default};
